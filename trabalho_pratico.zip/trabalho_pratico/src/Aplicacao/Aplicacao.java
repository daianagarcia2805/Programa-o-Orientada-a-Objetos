package Aplicacao;

import trabalho_pratico.Usuario;
import trabalho_pratico.Cartao;
import trabalho_pratico.Desks001;
import trabalho_pratico.Baralho;
import trabalho_pratico.Card001;
import trabalho_pratico.User001;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Aplicacao {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        User001 user = new User001();
        Usuario usuario = null;

        System.out.println("BEM VINDO AO SISTEMA DE MEMORIZAÇÃO ESPAÇADA ");

        while (true) {
            System.out.println("MENU DE OPÇÕES:");
            System.out.println("1. Acessar usuário ou criar novo usuário");
            System.out.println("2. Acessar baralho ou criar novo Baralho");
            System.out.println("0. Sair");

            int escolhaUser = scanner.nextInt();
            scanner.nextLine(); 

            switch (escolhaUser) {
                case 1:
                    Usuario.acessarOuCriarUsuario(usuario);
                    break;

                case 2:
                    Usuario.acessarOuCriarBaralho(usuario);
                    break;

                case 0:
                    System.out.println("Saindo do sistema...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Opção inválida. Por favor, escolha uma opção válida.");
                    break;
            }
        }
    }
}