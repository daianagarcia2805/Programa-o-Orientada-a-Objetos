package Aplicacao;

import trabalho_pratico.Usuario;
import trabalho_pratico.cartao;
import trabalho_pratico.desks001;
import trabalho_pratico.baralho;
import trabalho_pratico.card001;
import trabalho_pratico.user001;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Aplicacao {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        user001 user = new user001();
        Usuario usuario = null;

        System.out.println("BEM VINDO AO SISTEMA DE MEMORIZAÇÃO ESPAÇADA FÊNIX");

        while (true) {
            System.out.println("MENU DE OPÇÕES:");
            System.out.println("1. Acessar usuário ou criar novo usuário");
            System.out.println("2. Acessar baralho ou criar novo Baralho");
            System.out.println("0. Sair");

            int escolhaUser = scanner.nextInt();
            scanner.nextLine();  // Consumir a nova linha

            switch (escolhaUser) {
                case 1:
                    Usuario.acessarOuCriarUsuario(usuario);
                    break;

                case 2:
                    Usuario.acessarOuCriarBaralho(usuario);
                    break;

                case 0:
                    System.out.println("Saindo do sistema...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Opção inválida. Por favor, escolha uma opção válida.");
                    break;
            }
        }
    }
}