package trabalho_pratico;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDateTime;
import java.util.Scanner;
import java.time.LocalDate;

public class Card001 {

	private static final String URL = "jdbc:postgresql://localhost:5432/trabalho";
	private static final String USUARIO = "postgres";
	private static final String SENHA = "postgres";

	public static List<Cartao> buscarCartoes() {
		List<Cartao> cartoes = new ArrayList<>();
		String sql = "SELECT id, frente, verso, data_ultima_revisao, data_criacao, revisoes_realizadas FROM cartoes";

		try (Connection conn = DriverManager.getConnection(URL, USUARIO, SENHA);
				PreparedStatement stmt = conn.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery()) {

			while (rs.next()) {
				int id = rs.getInt("id");
				String frente = rs.getString("frente");
				String verso = rs.getString("verso");
				LocalDate dataUltimaRevisao = rs.getObject("data_ultima_revisao", LocalDate.class);
				LocalDate dataCriacao = rs.getObject("data_criacao", LocalDate.class);
				int revisoesRealizadas = rs.getInt("revisoes_realizadas");

				Cartao novoCartao = new Cartao(frente, verso);
				novoCartao.setId(id);
				novoCartao.setDataUltimaRevisao(dataUltimaRevisao);
				novoCartao.setDataCriacao(dataCriacao);
				novoCartao.setRevisoesRealizadas(revisoesRealizadas);

				cartoes.add(novoCartao);
			}
		} catch (SQLException e) {
			System.err.println("Erro ao buscar cartões: " + e.getMessage());
		}

		return cartoes;
	}

	public static void inserirCartaoNoBancoDeDados(int idBaralho, Cartao novoCartao) {
		try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/trabalho",
				"postgres", "postgres")) {
			String sql = "INSERT INTO cartoes (frente, verso, data_criacao, id_baralho) VALUES (?, ?, ?, ?)";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setString(1, novoCartao.getFrente());
				statement.setString(2, novoCartao.getVerso());
				statement.setObject(3, LocalDate.now());
				statement.setInt(4, idBaralho);
				statement.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void atualizarDataUltimaRevisaoNoBancoDeDados(Cartao cartao) { ///metodo x
		try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/trabalho",
				"postgres", "postgres")) {
			String sql = "UPDATE cartoes SET data_ultima_revisao = ? WHERE id = ?";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setObject(1, cartao.getDataUltimaRevisao());
				statement.setInt(2, cartao.getId());
				statement.executeUpdate();
			}
		} catch (SQLException e) {
			System.err.println("Erro ao atualizar a data da última revisão: " + e.getMessage());
		}
	}

	
	public static List<Cartao> buscarCartoesPorBaralho(int idBaralho) {
		List<Cartao> cartoes = new ArrayList<>();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/trabalho", "postgres", "postgres");
			String query = "SELECT * FROM cartoes WHERE id_baralho = ?";
			stmt = conn.prepareStatement(query);
			stmt.setInt(1, idBaralho);
			rs = stmt.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String frente = rs.getString("frente");
				String verso = rs.getString("verso");
				int idBaralhoBD = rs.getInt("id_baralho");

				// Verifica se a data de última revisão não é nula antes de converter para
				// LocalDate
				LocalDate dataUltimaRevisao = null;
				java.sql.Date dataUltimaRevisaoSQL = rs.getDate("data_ultima_revisao");
				if (dataUltimaRevisaoSQL != null) {
					dataUltimaRevisao = dataUltimaRevisaoSQL.toLocalDate();
				}

				// Verifica se a data de criação não é nula antes de converter para LocalDate
				LocalDate dataCriacao = null;
				java.sql.Date dataCriacaoSQL = rs.getDate("data_criacao");
				if (dataCriacaoSQL != null) {
					dataCriacao = dataCriacaoSQL.toLocalDate();
				}

				// Obtém revisões realizadas diretamente do ResultSet
				int revisoesRealizadas = rs.getInt("revisoes_realizadas");

				Cartao c = new Cartao(id, frente, verso, idBaralhoBD, dataUltimaRevisao, revisoesRealizadas,
						dataCriacao);
				cartoes.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return cartoes;
	}

	public static void atualizarCartao(Cartao cartao) {

		try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/trabalho",
				"postgres", "postgres")) {
			String sql = "UPDATE cartoes SET frente = ?, verso = ?, data_ultima_revisao = ?, revisoes_realizadas = ? WHERE id = ?";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setString(1, cartao.getFrente());
				statement.setString(2, cartao.getVerso());
				statement.setObject(3, cartao.getDataUltimaRevisao());
				statement.setInt(4, cartao.getRevisoesRealizadas());
				statement.setInt(5, cartao.getId());
				statement.executeUpdate();
			}
		} catch (SQLException e) {
			System.err.println("Erro ao atualizar o cartão: " + e.getMessage());
		}
	}
	private static void inserirCartaoNoBancoDeDados(int idUsuario, int idBaralho, String frente, String verso) {
		try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/trabalho",
				"postgres", "postgres")) {
			String sql = "INSERT INTO cartoes (frente, verso, id_baralho, id_usuario) VALUES (?, ?, ?, ?)";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setString(1, frente);
				statement.setString(2, verso);
				statement.setInt(3, idBaralho);
				statement.setInt(4, idUsuario);
				statement.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

