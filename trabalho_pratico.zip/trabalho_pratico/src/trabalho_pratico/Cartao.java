package trabalho_pratico;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate; //representar datas e horas.
import java.util.ArrayList; // implementação da interface List que usa um array para armazenar os elementos
import java.util.Iterator; //usada para iterar sobre elementos em uma coleção.
import java.util.List; // coleção ordenada de elementos.
import java.util.Scanner; // obter entrada do usuário a partir do teclado.
import java.time.LocalDateTime;

public class Cartao {

	private int id;
	private int id_baralho;
	private String frente;
	private String verso;
	private LocalDate dataUltimaRevisao;
	private LocalDate dataCriacao;
	private int revisoesRealizadas;
	private static List<Cartao> listaCartoes = new ArrayList<>();

	Scanner scan = new Scanner(System.in);

	public Cartao(String frente, String verso) {

		this.frente = frente;
		this.verso = verso;
		this.dataCriacao = LocalDate.now();
		this.dataUltimaRevisao = null;
		this.revisoesRealizadas = 0;
		listaCartoes.add(this);
	}

	public Cartao(int id, String frente, String verso, int id_baralho) {
		this.id = id;
		this.id_baralho = id_baralho;
		this.frente = frente;
		this.verso = verso;
		this.dataCriacao = LocalDate.now();
		this.dataUltimaRevisao = null;
		this.revisoesRealizadas = 0;
		listaCartoes.add(this);
	}

	public Cartao(int id, String frente, String verso, int id_baralho, LocalDate dataUltimaRevisao,
			int revisoesRealizadas, LocalDate dataCriacao) {
		this.id = id;
		this.id_baralho = id_baralho;
		this.frente = frente;
		this.verso = verso;
		this.dataCriacao = dataCriacao;
		this.dataUltimaRevisao = dataUltimaRevisao;
		this.revisoesRealizadas = revisoesRealizadas;
		listaCartoes.add(this);
	}

	public void incrementarContagemRevisoes() {
		this.revisoesRealizadas++; // Incrementa a contagem de revisões
	}

	public void setId_baralho(int id_baralho) { // SET FRENTE
		this.id_baralho = id_baralho;
	}

	public int getId_baralho() { // GET FRENTE
		return id_baralho;
	}

	public void setId(int id) { // SET FRENTE
		this.id = id;
	}

	public int getId() { // GET FRENTE
		return id;
	}

	public void setFrente(String frente) { // SET FRENTE
		this.frente = frente;
	}

	public String getFrente() { // GET FRENTE
		return frente;
	}

	public void setVerso(String verso) { // SET VERSO
		this.verso = verso;
	}

	public String getVerso() { // GET VERSO
		return verso;
	}

	public void setDataUltimaRevisao(LocalDate dataUltimaRevisao) { // SET DATA ULTIMA REVISAO

		this.dataUltimaRevisao = dataUltimaRevisao;
	}

	public LocalDate getDataUltimaRevisao() { // GET DATA ULTIMA REVISAO
		return dataUltimaRevisao;
	}

	public void setDataCriacao(LocalDate dataCriacao) { // SET DATA CRIACAO

		this.dataCriacao = dataCriacao;
	}

	public LocalDate getDataCriacao() { // GET DATA CRIACAO
		return dataCriacao;
	}

	public static List<Cartao> getListaCartoes() { // método estático que retorna a lista de cartões.
		return listaCartoes;
	}

	public void setRevisoesRealizadas(int revisoesRealizadas2) {
		this.revisoesRealizadas = revisoesRealizadas2;
	}

	public int getRevisoesRealizadas() {
		return this.revisoesRealizadas;
	}

	public static void adicionarCartao(int idBaralho, String frente, String verso) {
		Cartao novoCartao = new Cartao(frente, verso);
		novoCartao.setId_baralho(idBaralho); // Define o ID do baralho para o novo cartão
		System.out.println("Data de criação : " + novoCartao.getDataCriacao());
		novoCartao.setFrente(frente);
		novoCartao.setVerso(verso);
		Card001.inserirCartaoNoBancoDeDados(idBaralho, novoCartao); // Insere o cartão no banco de dados
		System.out.println("Cartão adicionado com sucesso!");
	}

	public boolean confirmarRevisao() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Revisar cartão? (s/n)");
		String resposta = scanner.nextLine();
		return resposta.equalsIgnoreCase("s");
	}

	public void revisar() {
		this.dataUltimaRevisao = LocalDate.now();
		this.revisoesRealizadas++;
		Card001.atualizarDataUltimaRevisaoNoBancoDeDados(this); // Atualiza a data da última revisão no banco de dados
	}

	public int calcularProximoIntervaloRevisao() {
		final int[] intervalos = { 1, 7, 30 }; // Intervalos de revisão: 1 dia, 7 dias, 30 dias
		int intervalo = 0;

		if (revisoesRealizadas == 1) {
			intervalo = intervalos[0]; // 1 dia
		} else if (revisoesRealizadas == 2) {
			intervalo = intervalos[1]; // 7 dias
		} else {
			intervalo = intervalos[2]; // 30 dias
		}

		// System.out.println("Número de revisões realizadas: " + revisoesRealizadas +
		// ", Intervalo calculado: " + intervalo);
		return intervalo;
	}

	public boolean precisaRevisar() {
		// System.out.println("Data última revisão: " + dataUltimaRevisao);
		if (dataUltimaRevisao == null) {
			//System.out.println("Nunca revisado, precisa revisar.");
			return true; // Se o cartão nunca foi revisado, ele precisa ser revisado agora
		}

		LocalDate proximaRevisao = dataUltimaRevisao.plusDays(calcularProximoIntervaloRevisao());
		// System.out.println("Data próxima revisão: " + proximaRevisao);
		// System.out.println("Data atual: " + LocalDate.now());

		boolean precisaRevisar = LocalDate.now().isAfter(proximaRevisao) || LocalDate.now().isEqual(proximaRevisao);
		// System.out.println("Precisa revisar: " + precisaRevisar);

		return precisaRevisar;
	}

	public void revisarCartoes() {
		Scanner scanner = new Scanner(System.in);

		for (Cartao c : listaCartoes) {
			if (c.precisaRevisar()) {
				System.out.println("Frente do cartão: " + c.getFrente());
				System.out.println("Deseja ver o verso deste cartão? (s/n)");

				String resposta = scanner.nextLine();

				if (resposta.equalsIgnoreCase("s")) {
					System.out.println("Verso do cartão: " + c.getVerso());
					c.revisar(); // Marca o cartão como revisado
					c.setDataUltimaRevisao(LocalDate.now()); // Atualiza a data da última revisão
				}
			}
		}
	}

	public static void adicionarNovosCartoes(int idBaralho) {
		Scanner scanner = new Scanner(System.in);
		boolean continuarAdicionando = true;

		while (continuarAdicionando) {
			System.out.println("Digite a frente do novo cartão ou 'fim' para parar:");
			String frente = scanner.nextLine();

			if (frente.equalsIgnoreCase("fim")) {
				continuarAdicionando = false;
				break;
			}

			System.out.println("Digite o verso do novo cartão:");
			String verso = scanner.nextLine();

			// Adicionar o novo cartão ao baralho
			Cartao.adicionarCartao(idBaralho, frente, verso);

			System.out.println("Novo cartão adicionado com sucesso!");
		}
	}

}