package trabalho_pratico;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.beans.Statement;
// acesso e manipulação de banco de dados usando JDBC
import java.sql.Connection;  // Representa uma conexão com um banco de dados.
import java.sql.DriverManager; // É responsável por registrar e gerenciar drivers JDBC, fornece métodos para registrar drivers de banco de dados, obter conexões e gerenciar transações.
import java.sql.PreparedStatement; //  fornece melhor desempenho e segurança contra injeção de SQL do que a classe Statement comum.
import java.sql.ResultSet; //permite iterar sobre os registros retornados pela consulta e acessar os valores das colunas.
import java.sql.SQLException; //é usada para lidar com erros relacionados ao SQL.
import java.time.LocalDateTime;

public class User001 { // É uma classe responsável por lidar com a persistência dos objetos  no banco de dados.

	    private static final String URL = "jdbc:postgresql://localhost:5432/trabalho";
	    private static final String USUARIO = "postgres";
	    private static final String SENHA = "postgres";
	    // Lista de usuários
	    public static List<Usuario> usuarios = new ArrayList<>();
	    

	    public static int salvarUsuario(Usuario usuario) {
	        int idGerado = -1; // Valor padrão caso não seja possível recuperar o ID gerado

	        try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA)) {
	            String sql = "INSERT INTO usuarios (nome, email, senha, data_criacao) VALUES (?, ?, ?, ?)";
	            try (PreparedStatement pstmt = conexao.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
	                pstmt.setString(1, usuario.getNome());
	                pstmt.setString(2, usuario.getEmail());
	                pstmt.setString(3, usuario.getSenha());
					pstmt.setDate(4, java.sql.Date.valueOf(usuario.getDataCriacao()));
	                int linhasAfetadas = pstmt.executeUpdate();

	                // Verificar se a inserção foi bem-sucedida
	                if (linhasAfetadas == 1) {
	                    // Obtém o ID gerado pelo banco de dados
	                    try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
	                        if (generatedKeys.next()) {
	                            idGerado = generatedKeys.getInt(1);
	                            usuario.setId(idGerado); 
	                            System.out.println("ID gerado para o usuário: " + idGerado); 
	                        } else {
	                            throw new SQLException("Nenhum ID gerado após a inserção do usuário.");
	                        }
	                    }
	                } else {
	                    throw new SQLException("A inserção do usuário não afetou uma única linha na tabela.");
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace(); // Imprimir detalhes do erro
	            System.err.println("Erro ao salvar usuário: " + e.getMessage());
	        }

	        return idGerado;
	    }

	    

	   
	    
	    public static Usuario getUsuarioByEmailSenha(String email, String senha) {
	        String sql = "SELECT id, nome, email, senha, data_criacao FROM usuarios WHERE email = ? AND senha = ?";
	        
	        try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
	             PreparedStatement pstmt = conexao.prepareStatement(sql)) {
	            pstmt.setString(1, email);
	            pstmt.setString(2, senha);
	            
	            try (ResultSet rs = pstmt.executeQuery()) {
	                if (rs.next()) {
	                    int id = rs.getInt("id");
	                    String nome = rs.getString("nome");
	                    LocalDate dataCriacao = rs.getObject("data_criacao", LocalDate.class);
	                    return new Usuario(id, nome, email, senha, dataCriacao); 
	                }
	            }
	        } catch (SQLException e) {
	            System.err.println("Erro ao buscar usuário por e-mail e senha: " + e.getMessage());
	        }
	        
	        return null;
	    }

}
