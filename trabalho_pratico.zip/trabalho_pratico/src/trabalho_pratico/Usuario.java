package trabalho_pratico;

import java.util.Iterator; //usada para iterar sobre elementos em uma coleção.
import java.util.ArrayList; // pacote para criação de lista de arrays
import java.util.List; // pacote para criação de listas
import java.util.Scanner;
import java.sql.Date; // pacote para ter acesso a classe LocalDate
import java.time.LocalDate; // pacote para ser acesso a classe LocalDate
import java.sql.Connection; // estabelecer conexão com postgree
import java.sql.PreparedStatement;// consultas sql
import java.time.LocalDateTime;

public class Usuario { //ATRIBUTOS

	private int id;
	private String nome;
	private String email;
	private String senha;
	private LocalDate dataCriacao;
	private List<Baralho> decks; // lista ordenada de elementos
	private List<Usuario> usuarios;

	static Scanner scan = new Scanner(System.in);

	public Usuario(String nome, String email, String senha) { //CONSTRUTOR
		this.nome = nome;
		this.email = email;
		this.senha = senha;
		this.dataCriacao = LocalDate.now();
		this.id = id;
		this.decks = new ArrayList<>(); // Inicializa a lista de baralhos
		this.usuarios = new ArrayList<>();
	}

	public Usuario(int id, String nome, String email, String senha, LocalDate dataCriacao) { // CONSTRUTOR
		this.id = id; // Atualiza o ID com o valor passado
		this.nome = nome;
		this.email = email;
		this.senha = senha;
		this.dataCriacao = dataCriacao; // Use a dataCriacao passada como argumento
		this.decks = new ArrayList<>(); // Inicializa a lista de baralhos
		this.usuarios = new ArrayList<>();
	}

	
	public void setDecks(List<Baralho> decks) { // SET decks

		this.decks = decks;
	}

	public void setId(int id) { // SET ID

		this.id = id;
	}

	public int getId() { // GET ID

		return id;
	}

	public List<Baralho> getDecks() { // GET decks

		return decks;
	}

	public void setNome(String nome) { // SET NOME

		this.nome = nome;
	}

	public String getNome() { // GET NOME

		return nome;
	}

	public void setEmail(String email) { // SET E-MAIL

		this.email = email;
	}

	public String getEmail() { // GET E-MAIL

		return email;
	}

	public void setSenha(String senha) { // SET SENHA

		this.senha = senha;
	}

	public String getSenha() { // GET SENHA

		return senha;
	}

	public void setDataCriacao(LocalDate dataCriacao) { // SET DATA CRIAÇÃO

		this.dataCriacao = dataCriacao;
	}

	public LocalDate getDataCriacao() { // GET DATA CRIAÇÃO

		return dataCriacao;
	}

	public Usuario getUsuarioByEmail(String email) {
		for (Usuario usuario : usuarios) { // for-each para iterar sobre cada Usuario na lista usuarios
			if (usuario.getEmail().equals(email)) { // equals para comparar os dois e-mails.
				return usuario;
			}
		}
		return null; // Retornar null se não encontrar nenhum usuário com o e-mail fornecido
	}

	
	// Adiciona um novo baralho pertencente ao usuário
	public void criarUsuario(Usuario usuario) {
		System.out.println("Seja Bem Vindo!!, para continuar, faça seu cadastro: ");
		System.out.println("Digite seu nome: ");
		this.setNome(scan.next());
		System.out.println("Digite seu E-mail : ");
		this.setEmail(scan.next());
		System.out.println("Digite a senha:");
		this.setSenha(scan.next());

		System.out.println("Nome: " + this.getNome());
		System.out.println("E-mail: " + this.getEmail());
		System.out.println("Senha: " + this.getSenha());
		System.out.println("data de criação: " + this.getDataCriacao());

	}

	
	public void adicionarBaralho(Baralho novoBaralho) {
		decks.add(novoBaralho);
	}

	public List<Cartao> getCartoesDisponiveisParaRevisao(List<Cartao> cartoes) {
		List<Cartao> cartoesDisponiveis = new ArrayList<>();
		for (Cartao card : cartoes) {
			if (card.precisaRevisar()) {
				cartoesDisponiveis.add(card);
			}
		}
		return cartoesDisponiveis;
	}

	

	// Método para criar um novo usuário ou acessar um existente
	public static Usuario criarOuAcessarUsuario() {
		Scanner scanner = new Scanner(System.in);
		Usuario usuario = null;

		System.out.println("Você já tem um usuário? (s/n)");
		String resposta = scanner.nextLine();

		if (resposta.equalsIgnoreCase("s")) {
			System.out.println("Digite seu email:");
			String email = scanner.nextLine();
			System.out.println("Digite sua senha:");
			String senha = scanner.nextLine();

			usuario = User001.getUsuarioByEmailSenha(email, senha);

			if (usuario == null) {
				System.out.println("Usuário não encontrado. Criando novo usuário...");
				usuario = criarNovoUsuario();
			} else {
				System.out.println("Usuário encontrado. Bem-vindo de volta, " + usuario.getNome() + "!");
			}
		} else {
			usuario = criarNovoUsuario();
		}

		return usuario;
	}

	public static Usuario acessarUsuarioExistente() {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Digite o email do usuário:");
		String email = scanner.nextLine();
		System.out.println("Digite a senha do usuário:");
		String senha = scanner.nextLine();

		// Realiza a busca do usuário no banco de dados
		Usuario usuario = User001.getUsuarioByEmailSenha(email, senha);

		// Verifica se o usuário foi encontrado
		if (usuario != null) {
			System.out.println("Usuário encontrado:");
			System.out.println("ID: " + usuario.getId());
			System.out.println("Nome: " + usuario.getNome());
			System.out.println("Email: " + usuario.getEmail());
			System.out.println("Senha: " + usuario.getSenha());
			System.out.println("Data de Criação: " + usuario.getDataCriacao());
		} else {
			System.out.println("Usuário não encontrado.");
		}

		return usuario;
	}

	public static Usuario retornarIdUsuario() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Digite o email do usuário:");
		String emailUsuario = scanner.nextLine();

		System.out.println("Digite a senha do usuário:");
		String senhaUsuario = scanner.nextLine();

		// Verifica se o email e a senha estão vazios
		if (emailUsuario.isEmpty() || senhaUsuario.isEmpty()) {
			System.out.println("Email ou senha não podem estar vazios.");
			return null;
		}

		// Obtém o usuário com o email e a senha fornecidos
		Usuario usuario = User001.getUsuarioByEmailSenha(emailUsuario, senhaUsuario);

		// Verifica se o usuário foi encontrado
		if (usuario != null) {
			System.out.println("Usuário encontrado:");
			System.out.println("Nome: " + usuario.getNome() + ", Email: " + usuario.getEmail() + ", Data de Criação: "
					+ usuario.getDataCriacao());
			return usuario;
		} else {
			// Se o usuário não for encontrado, exibe a mensagem de usuário não encontrado
			System.out.println("Usuário não encontrado.");
			return null;
		}
	}

	// Método para criar um novo usuário
	public static Usuario criarNovoUsuario() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Digite o nome do novo usuário:");
		String nome = scanner.nextLine();
		System.out.println("Digite o email do novo usuário:");
		String email = scanner.nextLine();
		System.out.println("Digite a senha do novo usuário:");
		String senha = scanner.nextLine();

		// Cria o novo usuário sem o ID, já que será gerado pelo banco de dados
		Usuario novoUsuario = new Usuario(nome, email, senha);

		// Salva o novo usuário no banco de dados e obtém o ID gerado
		int idGerado = User001.salvarUsuario(novoUsuario);

		// Atribui o ID gerado ao novo usuário
		novoUsuario.setId(idGerado);

		return novoUsuario;
	}

	public static void revisarOuAdicionarCartoes(Usuario usuario) {
	    Scanner scanner = new Scanner(System.in);

	    while (true) {
	        // Buscar os baralhos do usuário
	        System.out.println("Buscando baralhos do usuário:");
	        List<Baralho> baralhos = Desks001.buscarBaralhosDoUsuario(usuario);

	        if (baralhos.isEmpty()) {
	            System.out.println("Você não tem nenhum baralho existente.");
	            return;
	        }

	        System.out.println("Escolha um baralho para revisão:");
	        for (int i = 0; i < baralhos.size(); i++) {
	            System.out.println((i + 1) + ". " + baralhos.get(i).getNome());
	        }

	        int escolhaBaralho = scanner.nextInt();
	        scanner.nextLine(); // Limpar o buffer do scanner

	        if (escolhaBaralho < 1 || escolhaBaralho > baralhos.size()) {
	            System.out.println("Opção inválida.");
	            continue;  // Volta ao início do loop para mostrar o menu novamente
	        }

	        // Acessar o baralho escolhido
	        Baralho baralhoEscolhido = baralhos.get(escolhaBaralho - 1);

	        // Opções para revisar ou adicionar cartões
	        System.out.println("O que você deseja fazer?");
	        System.out.println("1. Revisar os cartões");
	        System.out.println("2. Adicionar novos cartões");
	        System.out.println("0. Voltar ao menu anterior");

	        int opcao = scanner.nextInt();
	        scanner.nextLine(); // Limpar o buffer do scanner

	        switch (opcao) {
	            case 1:
	                // Revisar os cartões do baralho escolhido
	                List<Cartao> cartoesDoBaralho = Card001.buscarCartoesPorBaralho(baralhoEscolhido.getId());
	                List<Cartao> cartoesParaRevisar = new ArrayList<>();
	                for (Cartao c : cartoesDoBaralho) {
	                    if (c.precisaRevisar()) {
	                        cartoesParaRevisar.add(c);
	                    }
	                }
	                Baralho.revisarCartoes(baralhoEscolhido, cartoesParaRevisar);
	                System.out.println("PARABÉNS !!! TODOS OS CARTÕES JÁ FORAM REVISADOS.");
	                break;
	            case 2:
	                // Adicionar novos cartões ao baralho escolhido
	                Cartao.adicionarNovosCartoes(baralhoEscolhido.getId());
	                System.out.println("Todos os cartões foram adicionados com sucesso!");
	                break;
	            case 0:
	                // Voltar ao menu anterior
	                return;
	            default:
	                System.out.println("Opção inválida.");
	        }
	    }
	}


	public static void acessarOuCriarUsuario(Usuario usuario) {
	    Scanner scan = new Scanner(System.in);

	    while (true) {
	        System.out.println("Você deseja acessar um usuário existente ou criar um novo?");
	        System.out.println("1. Acessar usuário existente");
	        System.out.println("2. Criar novo usuário");
	        System.out.println("0. Voltar ao menu anterior");

	        int escolhaUsuario = scan.nextInt();
	        scan.nextLine(); // Limpar o buffer do scanner

	        switch (escolhaUsuario) {
	            case 1:
	                usuario = Usuario.acessarUsuarioExistente(); 
	                if (usuario == null) {
	                    System.out.println("Usuário não encontrado. Criando um novo usuário...");
	                    usuario = Usuario.criarNovoUsuario(); 
	                }
	                return; // Usuário acessado ou criado, retornar ao menu principal
	            case 2:
	                usuario = Usuario.criarNovoUsuario();
	                return; // Usuário criado, retornar ao menu principal
	            case 0:
	                return; // Voltar ao menu anterior
	            default:
	                System.out.println("Opção inválida.");
	        }
	    }
	}


	public static void acessarOuCriarBaralho(Usuario usuario) {
	    Scanner scan = new Scanner(System.in);

	    while (true) {
	        System.out.println("Você deseja acessar um baralho existente ou criar um novo?");
	        System.out.println("1. Acessar baralho existente");
	        System.out.println("2. Criar novo baralho");
	        System.out.println("0. Voltar ao menu anterior");

	        int escolhaBaralho = scan.nextInt();
	        scan.nextLine(); // Limpar o buffer do scanner

	        switch (escolhaBaralho) {
	            case 1:
	                usuario = Usuario.acessarUsuarioExistente();
	                if (usuario != null) {
	                    usuario.revisarOuAdicionarCartoes(usuario);
	                } else {
	                    System.out.println("Usuário não encontrado.");
	                }
	                break;
	            case 2:
	                usuario = Usuario.acessarUsuarioExistente();
	                if (usuario == null) {
	                    System.out.println("Usuário não encontrado. Criando um novo usuário...");
	                    usuario = Usuario.criarNovoUsuario();
	                }
	                int idBaralhoCriado = Baralho.criarNovoBaralhoComOpcoes(usuario);
	                if (idBaralhoCriado != -1) {
	                    System.out.println("Baralho criado com sucesso! ID: " + idBaralhoCriado);
	                    // Chamar a função para revisar ou adicionar cartões após a criação do baralho
	                    Usuario.revisarOuAdicionarCartoes(usuario);
	                } else {
	                    System.out.println("Erro ao criar o baralho.");
	                }
	                break;
	            case 0:
	                return; // Voltar ao menu anterior
	            default:
	                System.out.println("Opção inválida.");
	        }
	    }
	}
}