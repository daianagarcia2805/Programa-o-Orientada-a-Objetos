
package trabalho_pratico;

import java.util.Iterator; //usada para iterar sobre elementos em uma coleção.
import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class baralho {
	//ATRIBUTOS
	private int id;
	private String nome;
	private int id_usuario;
	private List<cartao> cartoes;

	Scanner scan = new Scanner(System.in);

	public baralho(String nome, List<cartao> cartoes) { //CONSTRUTOR
		this.nome = nome;
		this.cartoes = cartoes;

	}

	public void setNome(String nome) { // SET NOME

		this.nome = nome;
	}

	public void setId(int id) { // SET ID

		this.id = id;
	}

	public int getId() { // GET ID
		return id;
	}

	public String getNome() { // GET NOME
		return nome;
	}

	public void setCards(List<cartao> cartoes) { // SET CARDS
		this.cartoes = cartoes;
	}

	public List<cartao> getCards() {// GET CARDS
		return cartoes;
	}

	public void adicionarCartao(cartao novoCartao) {
		cartoes.add(novoCartao);
	}

	public void listarCartoes() {
		System.out.println("Cartões do Baralho " + nome + ":");
		for (cartao cartao : cartoes) {
			System.out.println("Frente: " + cartao.getFrente() + ", Verso: " + cartao.getVerso());
		}
	}

// Método para criar um novo baralho com opções e inserir no PostgreSQL
	public static int criarNovoBaralhoComOpcoes(Usuario usuario) {
		Scanner scanner = new Scanner(System.in);

		// Verifica se o usuário é válido
		if (usuario == null) {
			System.out.println("Usuário inválido.");
			return -1; // Retorna -1 para indicar um erro
		}

		// Criar o novo baralho
		System.out.println("Digite o nome do novo baralho:");
		String nomeBaralho = scanner.nextLine();

		// Criar o novo baralho e adicioná-lo ao usuário
		baralho novoBaralho = new baralho(nomeBaralho, new ArrayList<>());
		usuario.adicionarBaralho(novoBaralho);

		System.out.println("Novo baralho criado com sucesso!");

		// Inserir o baralho no banco de dados
		int idBaralho = desks001.inserirBaralhoNoBancoDeDados(usuario.getId(), nomeBaralho);
		if (idBaralho == -1) {
			System.out.println("Erro ao inserir o baralho no banco de dados.");
			return -1; // Retorna -1 para indicar um erro
		} else {
			System.out.println("ID do baralho criado: " + idBaralho); // Adiciona este log
			return idBaralho; // Retorna o ID do baralho criado
		}
	}

	public static void adicionarNovosCartoes(int idUsuario) {
		Scanner scanner = new Scanner(System.in);

		// Criar um objeto Usuario com base no ID fornecido
		Usuario usuario = new Usuario(idUsuario, null, null, null, null);
		

		// Buscar os baralhos do usuário
		List<baralho> baralhos = desks001.buscarBaralhosDoUsuario(usuario);

		if (baralhos.isEmpty()) {
			System.out.println("Você não tem nenhum baralho existente para adicionar cartões.");
			return;
		}

		System.out.println("Escolha um baralho para adicionar novos cartões:");
		for (int i = 0; i < baralhos.size(); i++) {
			System.out.println((i + 1) + ". " + baralhos.get(i).getNome());
		}

		int escolhaBaralho = scanner.nextInt();
		scanner.nextLine(); // Limpar o buffer do scanner

		if (escolhaBaralho < 1 || escolhaBaralho > baralhos.size()) {
			System.out.println("Opção inválida.");
			return;
		}

		// Adicionar novos cartões ao baralho escolhido
		baralho baralhoEscolhido = baralhos.get(escolhaBaralho - 1);
		baralhoEscolhido.adicionarNovosCartoes(idUsuario);
	}

	public static void revisarOuAdicionarCartoes(baralho baralhoEscolhido) {
		Scanner scanner = new Scanner(System.in);

		System.out.println("O que você deseja fazer?");
		System.out.println("1. Revisar os cartões");
		System.out.println("2. Adicionar novos cartões");
		int escolha = scanner.nextInt();
		scanner.nextLine(); // Limpar o buffer do scanner

		switch (escolha) {
		case 1:
			// Revisar os cartões do baralho
			baralhoEscolhido.revisarCartoes();
			break;
		case 2:
			// Adicionar novos cartões ao baralho
			cartao.adicionarNovosCartoes(baralhoEscolhido.getId());
			break;
		default:
			System.out.println("Opção inválida.");
		}
	}

	public void revisarCartoes() {
		Scanner scanner = new Scanner(System.in);

		for (cartao c : cartoes) {
			if (c.precisaRevisar()) {
				System.out.println("Frente do cartão: " + c.getFrente());
				System.out.println("Deseja ver o verso deste cartão? (s/n)");

				String resposta = scanner.nextLine();

				if (resposta.equalsIgnoreCase("s")) {
					System.out.println("Verso do cartão: " + c.getVerso());

					// Solicita a data da revisão ao usuário e atualiza o cartão e o banco de dados
					LocalDate dataRevisao = LocalDate.now();
					c.revisar(); // Marca o cartão como revisado
					c.setDataUltimaRevisao(dataRevisao); // Atualiza a data da última revisão
					c.incrementarContagemRevisoes(); // Incrementa a contagem de revisões

					// Atualiza os dados do cartão no banco de dados
					card001.atualizarCartao(c);

					System.out.println("Cartão revisado em " + dataRevisao);
				}
			}
		}
	}

	public static void revisarCartoes(baralho baralhoEscolhido, List<cartao> cartoes) {
		Scanner scanner = new Scanner(System.in);
		for (cartao c : cartoes) {
			if (c.precisaRevisar()) {
				System.out.println("Frente do cartão: " + c.getFrente());
				System.out.println("Deseja ver o verso deste cartão? (s/n)");

				String resposta = scanner.nextLine();

				if (resposta.equalsIgnoreCase("s")) {
					System.out.println("Verso do cartão: " + c.getVerso());

					// Solicita a data da revisão ao usuário e atualiza o cartão e o banco de dados
					LocalDate dataRevisao = LocalDate.now();

					c.revisar(); // Marca o cartão como revisado
					c.setDataUltimaRevisao(dataRevisao); // Atualiza a data da última revisão
					// c.incrementarContagemRevisoes(); // Incrementa a contagem de revisões

					// Atualiza os dados do cartão no banco de dados
					card001.atualizarCartao(c);

					System.out.println("Cartão revisado em " + dataRevisao);
				}
			}
		}
	}

}
