package trabalho_pratico;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class desks001 {
	// É uma classe responsável por lidar com a persistência dos objetos no banco de
	// dados.

	private static final String URL = "jdbc:postgresql://localhost:5432/trabalho";
	private static final String USUARIO = "postgres";
	private static final String SENHA = "postgres";

	public static List<baralho> baralhos = new ArrayList<>();
	public static List<cartao> cartoes = new ArrayList<>();
	public static List<Usuario> usuarios = new ArrayList<>();

	// Método para inserir um baralho no banco de dados
	public static int inserirBaralhoNoBancoDeDados(int idUsuario, String nomeBaralho) {
		int idGerado = -1;

		try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA)) {
			String sql = "INSERT INTO baralhos (id_usuario, nome) VALUES (?, ?)";
			try (PreparedStatement pstmt = conexao.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
				pstmt.setInt(1, idUsuario);
				pstmt.setString(2, nomeBaralho);
				int linhasAfetadas = pstmt.executeUpdate();

				// Verificar se a inserção foi bem-sucedida
				if (linhasAfetadas == 1) {
					// Obtém o ID gerado pelo banco de dados
					try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
						if (generatedKeys.next()) {
							idGerado = generatedKeys.getInt(1);
							System.out.println("ID gerado para o baralho: " + idGerado);
						} else {
							throw new SQLException("Nenhum ID gerado após a inserção do baralho.");
						}
					}
				} else {
					throw new SQLException("A inserção do baralho não afetou uma única linha na tabela.");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace(); // Imprimir detalhes do erro
			System.err.println("Erro ao salvar baralho: " + e.getMessage());
		}

		return idGerado;
	}

	public static List<baralho> acessarBaralhoExistente(Usuario usuario) {
		Scanner scanner = new Scanner(System.in);
		List<baralho> baralhos = new ArrayList<>();

		// Conectar ao banco de dados
		try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA)) {
			// Consulta SQL para obter os baralhos do usuário
			String sql = "SELECT * FROM baralhos WHERE id_usuario = ?";
			try (PreparedStatement pstmt = conexao.prepareStatement(sql)) {
				pstmt.setInt(1, usuario.getId());
				ResultSet rs = pstmt.executeQuery();

				// Exibir os baralhos do usuário
				int count = 1;
				while (rs.next()) {
					int idBaralho = rs.getInt("id");
					String nomeBaralho = rs.getString("nome");
					baralho novoBaralho = new baralho(nomeBaralho, new ArrayList<>());
					novoBaralho.setId(idBaralho);
					baralhos.add(novoBaralho);
					System.out.println(count + ". " + nomeBaralho);
					count++;
				}

				if (baralhos.isEmpty()) {
					System.out.println("Você não tem nenhum baralho existente.");
					return baralhos; // Retorna uma lista vazia se não houver baralhos
				}

				System.out.println("Escolha um baralho para acessar:");
				int escolhaBaralho = scanner.nextInt();
				scanner.nextLine(); // Limpar o buffer do scanner

				if (escolhaBaralho < 1 || escolhaBaralho > baralhos.size()) {
					System.out.println("Opção inválida.");
					return baralhos; // Retorna a lista de baralhos sem fazer nada se a opção for inválida
				}

				// Retorna o baralho escolhido
				List<baralho> baralhoEscolhido = new ArrayList<>();
				baralhoEscolhido.add(baralhos.get(escolhaBaralho - 1));
				return baralhoEscolhido;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro ao acessar os baralhos existentes.");
		}
		return baralhos; // Retorna a lista de baralhos se ocorrer algum erro
	}

	public static List<baralho> buscarBaralhosDoUsuario(Usuario usuario) {
		List<baralho> baralhos = new ArrayList<>();
		// Conectar ao banco de dados
		try (Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA)) {
			// Consulta SQL para obter os baralhos do usuário
			String sql = "SELECT * FROM baralhos WHERE id_usuario = ?";
			try (PreparedStatement pstmt = conexao.prepareStatement(sql)) {
				pstmt.setInt(1, usuario.getId());
				ResultSet rs = pstmt.executeQuery();

				// Exibir os baralhos do usuário
				while (rs.next()) {
					int idBaralho = rs.getInt("id");
					String nomeBaralho = rs.getString("nome");
					baralho novoBaralho = new baralho(nomeBaralho, new ArrayList<>());
					novoBaralho.setId(idBaralho);
					baralhos.add(novoBaralho);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Erro ao acessar os baralhos existentes.");
		}
		return baralhos;
	}
}
